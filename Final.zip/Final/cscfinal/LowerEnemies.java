/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cscfinal;

/**
 *
 * @author Mikhail
 */
import basicgraphics.BasicFrame;
import basicgraphics.CollisionEventType;
import basicgraphics.Sprite;
import basicgraphics.SpriteCollisionEvent;
import basicgraphics.SpriteComponent;
import basicgraphics.images.Picture;
import basicgraphics.sounds.ReusableClip;
import static cscfinal.Gestalt.BOARD_SIZE;
import static cscfinal.Gestalt.ENEMIES;
import static cscfinal.LowerEnemies.enemyCount;
import java.applet.AudioClip;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author sbrandt
 */
public class LowerEnemies extends Sprite {

    SpriteComponent sc;
    static int enemyCount;
    int count = 0;
    //probably not the best way to do this, but I want to be able to have a lives option.
    //For this, I'm setting the lives to 3.
    static int livesLost;

    LowerEnemies() {
        enemyCount++;
    }

    @Override
    public void setActive(boolean b) {
        if (isActive() == b) {
            return;
        }
        if (b) {
            enemyCount++;
        } else {
            enemyCount--;
        }
        super.setActive(b);
    }

    public static Picture makeBall(Color color, int size) {
        Image im = BasicFrame.createImage(size, size);
        Graphics g = im.getGraphics();
        g.setColor(color);
        g.fillOval(0, 0, size, size);
        return new Picture(im);
    }

    public void init(SpriteComponent sc) {
        setPicture(makeBall(Color.lightGray, 10));
        while (true) {
            setX(Gestalt.RAND.nextInt(Gestalt.BOARD_SIZE.width) - Gestalt.SMALL);
            setY(Gestalt.RAND.nextInt(Gestalt.BOARD_SIZE.height) - Gestalt.SMALL);
            if (Math.abs(getX() - Gestalt.BOARD_SIZE.width / 2.5) < 2 * Gestalt.BIG
                    && Math.abs(getY() - Gestalt.BOARD_SIZE.height / 2.5) < 2 * Gestalt.BIG) {
                // Overlaps with center-ISH, try again
            } else {
                break;
            }
        }
        // A random speed
        setVelX(1 * Gestalt.RAND.nextDouble() - .5);
        setVelY(1 * Gestalt.RAND.nextDouble() - .5);
        sc.addSprite(this);
        this.sc = sc;
    }

    AudioClip clip = new ReusableClip("die.wav");

    @Override
    public void processEvent(SpriteCollisionEvent se) {
        if (se.eventType == CollisionEventType.WALL_INVISIBLE) {
            if (se.xlo) {
                setX(sc.getSize().width - getWidth());
            }
            if (se.xhi) {
                setX(0);
            }
            if (se.ylo) {
                setY(sc.getSize().height - getHeight());
            }
            if (se.yhi) {
                setY(0);
            }
            if (se.xlo) {
                setVelX((getVelX()));
            }
            if (se.xhi) {
                setVelX(-(getVelX()));
            }
            if (se.ylo) {
                setVelY((getVelY()));
            }
            if (se.yhi) {
                setVelY(-(getVelY()));
            }
        }

        if (se.sprite2 instanceof HackerBullets) {
            clip.play();
            setActive(false);
            se.sprite2.setActive(false);

            if (enemyCount == 25) {
                JOptionPane.showMessageDialog(sc, "Hacking complete! Accessing level 2...");
                try {
                    level2();
                } catch (IOException ex) {
                    Logger.getLogger(LowerEnemies.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            if (enemyCount == 5) {
                JOptionPane.showMessageDialog(sc, "Hacking complete! Accessing level 3...");
                try {
                    level3();
                } catch (IOException ex) {
                    Logger.getLogger(LowerEnemies.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            if (enemyCount == 0) {
                JOptionPane.showMessageDialog(sc, "Hacking complete! Accessing final level...");
                JOptionPane.showMessageDialog(sc, "The boss' barrier broke! Destroy it!");
                try {
                    levelFINAL();
                } catch (IOException ex) {
                    Logger.getLogger(LowerEnemies.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }

    private void level2() throws IOException {
        BasicFrame bf = new BasicFrame("Gestalt");
        final SpriteComponent sc = new SpriteComponent() {
            @Override
            public void paintBackground(Graphics g) {
                Dimension d = getSize();
                g.setColor(Color.darkGray);
                g.fillRect(0, 0, d.width, d.height);

                g.setColor(Color.gray);
                int k;
                int htOfRow = d.height / (75);
                for (k = 0; k < 100; k++) {
                    g.drawLine(0, k * htOfRow, d.width, k * htOfRow);
                }

                int wdOfRow = d.width / (75);
                for (k = 0; k < 100; k++) {
                    g.drawLine(k * wdOfRow, 0, k * wdOfRow, d.height);
                }
            }
        };
        sc.setPreferredSize(BOARD_SIZE);
        bf.add("Gestalt", sc, 0, 0, 1, 1);
        bf.show();
        for (int i = 0; i < 25; i++) {
            LowerEnemies en = new LowerEnemies();
            en.init(sc);
        }

        BossEnemy en = new BossEnemy();
        en.init(sc);

        final Hacker f = new Hacker();
        final BossEnemy b = new BossEnemy();
        final double INCR = Math.PI * 2 / 100.0;
        bf.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent ke) {
                count = 0;
                if (ke.getKeyCode() == KeyEvent.VK_RIGHT) {
                    f.turn(INCR);
                } else if (ke.getKeyCode() == KeyEvent.VK_LEFT) {
                    f.turn(-INCR);
                } else if (ke.getKeyCode() == KeyEvent.VK_UP) {
                    f.setVelY(f.getVelY() - .05);
                } else if (ke.getKeyCode() == KeyEvent.VK_DOWN) {
                    f.setVelY(f.getVelY() + .05);
                } else if (ke.getKeyChar() == ' ') {
                    // player's bullets
                    HackerBullets pl = new HackerBullets();
                    pl.setVelX(f.getVelX() * 2);
                    pl.setVelY(f.getVelY() * 2);
                    pl.setX(f.getX() + f.getWidth() * .5);
                    pl.setY(f.getY() + f.getHeight() * .5);
                    pl.init(sc);
                    sc.addSprite(pl);

                    // Enemy's new bullets lol have fun
                    EnemyBullets el = new EnemyBullets();
                    el.setVelX(f.getVelX());
                    el.setVelY(f.getVelY());
                    el.setX(Math.random() * 800);
                    el.setY(Math.random() * 400);
                    el.init(sc);
                    sc.addSprite(el);

                }
            }
        });

        f.init(sc);
        sc.start(0, 10);
    }

    private void level3() throws IOException {
        BasicFrame bf = new BasicFrame("Gestalt");
        final SpriteComponent sc = new SpriteComponent() {
            @Override
            public void paintBackground(Graphics g) {
                Dimension d = getSize();
                g.setColor(Color.darkGray);
                g.fillRect(0, 0, d.width, d.height);

                g.setColor(Color.gray);
                int k;
                int htOfRow = d.height / (75);
                for (k = 0; k < 100; k++) {
                    g.drawLine(0, k * htOfRow, d.width, k * htOfRow);
                }

                int wdOfRow = d.width / (75);
                for (k = 0; k < 100; k++) {
                    g.drawLine(k * wdOfRow, 0, k * wdOfRow, d.height);
                }
            }
        };
        sc.setPreferredSize(BOARD_SIZE);
        bf.add("Gestalt", sc, 0, 0, 1, 1);
        bf.show();
        for (int i = 0; i < 5; i++) {
            LowerEnemies en = new LowerEnemies();
            en.init(sc);
        }

        final Hacker f = new Hacker();
        final double INCR = Math.PI * 2 / 100.0;
        bf.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent ke) {
                count = 0;
                if (ke.getKeyCode() == KeyEvent.VK_RIGHT) {
                    f.turn(INCR);
                } else if (ke.getKeyCode() == KeyEvent.VK_LEFT) {
                    f.turn(-INCR);
                } else if (ke.getKeyCode() == KeyEvent.VK_UP) {
                    f.setVelY(f.getVelY() - .05);
                } else if (ke.getKeyCode() == KeyEvent.VK_DOWN) {
                    f.setVelY(f.getVelY() + .05);

                } else if (ke.getKeyChar() == ' ') {
                    HackerBullets pl = new HackerBullets();
                    pl.setVelX(f.getVelX() * 2);
                    pl.setVelY(f.getVelY() * 2);
                    pl.setX(f.getX() + f.getWidth() * .5);
                    pl.setY(f.getY() + f.getHeight() * .5);
                    pl.init(sc);
                    sc.addSprite(pl);

                    EnemyBullets el = new EnemyBullets();
                    el.setVelX(f.getVelX());
                    el.setVelY(f.getVelY());
                    el.setX(Math.random() * 800);
                    el.setY(Math.random() * 400);
                    el.init(sc);
                    sc.addSprite(el);

                }
            }
        });

        f.init(sc);
        sc.start(0, 10);
    }

    private void levelFINAL() throws IOException {
        BasicFrame bf = new BasicFrame("Gestalt");
        final SpriteComponent sc = new SpriteComponent() {
            @Override
            public void paintBackground(Graphics g) {
                Dimension d = getSize();
                g.setColor(Color.darkGray);
                g.fillRect(0, 0, d.width, d.height);

                g.setColor(Color.gray);
                int k;
                int htOfRow = d.height / (75);
                for (k = 0; k < 100; k++) {
                    g.drawLine(0, k * htOfRow, d.width, k * htOfRow);
                }

                int wdOfRow = d.width / (75);
                for (k = 0; k < 100; k++) {
                    g.drawLine(k * wdOfRow, 0, k * wdOfRow, d.height);
                }
            }
        };
        sc.setPreferredSize(BOARD_SIZE);
        bf.add("Gestalt", sc, 0, 0, 1, 1);
        bf.show();

        for (int i = 0; i < 5; i++) {
            ShootEnemies enl = new ShootEnemies();
            enl.init(sc);
        }
        
        BossEnemy en = new BossEnemy();
        en.init(sc);
        final ShootEnemies e = new ShootEnemies();
        final Hacker f = new Hacker();
        final BossEnemy b = new BossEnemy();
        final double INCR = Math.PI * 2 / 100.0;
        bf.addKeyListener(new KeyAdapter() {

            @Override
            public void keyPressed(KeyEvent ke) {
                count = 0;
                if (ke.getKeyCode() == KeyEvent.VK_RIGHT) {
                    f.turn(INCR);
                } else if (ke.getKeyCode() == KeyEvent.VK_LEFT) {
                    f.turn(-INCR);
                } else if (ke.getKeyCode() == KeyEvent.VK_UP) {
                    f.setVelY(f.getVelY() - .05);
                } else if (ke.getKeyCode() == KeyEvent.VK_DOWN) {
                    f.setVelY(f.getVelY() + .05);
                } else if (ke.getKeyChar() == ' ') {
                    HackerBullets pl = new HackerBullets();
                    pl.setVelX(f.getVelX() * 2);
                    pl.setVelY(f.getVelY() * 2);
                    pl.setX(f.getX() + f.getWidth() * .5);
                    pl.setY(f.getY() + f.getHeight() * .5);
                    pl.init(sc);
                    sc.addSprite(pl);

                    IndestructableBullets el = new IndestructableBullets();
                    el.setVelX(b.getVelX()*3);
                    el.setVelY(b.getVelY()*3);
                    el.setX(b.getX() + b.getWidth() * .5);
                    el.setY(b.getY() + b.getHeight() * .5);
                    el.init(sc);
                    sc.addSprite(el);
                    
                    EnemyBullets eb = new EnemyBullets();
                    eb.setVelX(b.getVelX());
                    eb.setVelY(b.getVelY());
                    eb.setX(e.getX() + b.getHeight() * 2);
                    eb.setY(e.getY() + b.getHeight()* 2);
                    eb.init(sc);
                    sc.addSprite(eb);

                }
            }
        });
        
        b.init(sc);
        f.init(sc);
        sc.start(0, 10);
    }
}
