/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cscfinal;

/**
 *
 * @author Mikhail
 */
import basicgraphics.BasicFrame;
import basicgraphics.Sprite;
import basicgraphics.SpriteCollisionEvent;
import basicgraphics.SpriteComponent;
import basicgraphics.images.Picture;
import basicgraphics.sounds.ReusableClip;
import java.applet.AudioClip;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;

/**
 *
 * @author sbrandt
 */
class HackerBullets extends Sprite {
    
    /**
     * Creates a picture of a ball with the given color and size.
     * @param color
     * @param size
     * @return 
     */
    public static Picture makeRectangle(Color color,int size) {
        Image im = BasicFrame.createImage(size, size);
        Graphics g = im.getGraphics();
        g.setColor(color);
        g.fillRect(0, 0, size, size);
        return new Picture(im);
    }
    
    /**
     * Just sets the picture.
     * @param sc 
     */
    public void init(SpriteComponent sc) {
        setPicture(makeRectangle(Color.white,7));
    }
    
    //adds the lazer sound (hopefully)
    AudioClip clip2 = new ReusableClip("lazer.wav");
    
    /**
     * Disappears if it comes in contact with the display
     * boundary.
     * @param se 
     */
    @Override
    public void processEvent(SpriteCollisionEvent se) {
        if(se.sprite2 != null) {
            clip2.play();
        } else {
            clip2.play();
            setActive(false);
        }
    }
}