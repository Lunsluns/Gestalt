/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cscfinal;

/**
 *
 * @author Mikhail
 */
import basicgraphics.BasicFrame;
import basicgraphics.SpriteComponent;
import basicgraphics.images.Picture;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.Random;
import javax.swing.JOptionPane;

/**
 * This program creates a spaceship that flies
 * across a field at constant speed, turning left
 * or right when the player uses the arrow keys.
 * It also shoots of the space bar is pressed.
 * @author sbrandt
 */
public class Gestalt {
   final public static Random RAND = new Random(); 
   final public static int LIVES = 3;
   final public static int BIG = 20;
   final public static int SMALL = 5;
   final public static int ENEMIES = 50;
   final public static int SHOOTING_ENEMIES = 4;
   final public static int BOSS = 1;
   final public static Dimension BOARD_SIZE = new Dimension(800,400);
   final public static Color ENEMY_COLOR = Color.lightGray;
    
    public static void main(String[] args) throws IOException {
        
        BasicFrame bf = new BasicFrame("Gestalt");
        final SpriteComponent sc = new SpriteComponent() {
            
            @Override
            public void paintBackground(Graphics g) {
                Dimension d = getSize();
                g.setColor(Color.darkGray);
                g.fillRect(0, 0, d.width, d.height);
                
                g.setColor(Color.gray);
                int k;
                int htOfRow = d.height / (75);
                for (k = 0; k < 100; k++)
                    g.drawLine(0, k * htOfRow , d.width, k * htOfRow );

                int wdOfRow = d.width / (75);
                for (k = 0; k < 100; k++)
                    g.drawLine(k*wdOfRow , 0, k*wdOfRow , d.height);
            }
        };
        JOptionPane.showMessageDialog(sc,"Welcome to Gestalt!");
        JOptionPane.showMessageDialog(sc,"Starting hacking...");
        sc.setPreferredSize(BOARD_SIZE);
        bf.add("Gestalt",sc,0,0,1,1);
        bf.show();
        
        //creates the enemies
        
        for(int i=0;i<ENEMIES;i++) {
            LowerEnemies en = new LowerEnemies();
            en.init(sc);
        }
        
        final Hacker f = new Hacker();
        final double INCR = Math.PI*2/100.0;
        bf.addKeyListener(new KeyAdapter() {   
            @Override
            public void keyPressed(KeyEvent ke) {
                if(ke.getKeyCode() == KeyEvent.VK_RIGHT) {
                    f.turn( INCR);
                } else if(ke.getKeyCode() == KeyEvent.VK_LEFT) {
                    f.turn(-INCR);
                } else if (ke.getKeyCode() == KeyEvent.VK_UP) {
                    f.setVelY(f.getVelY() - .05);
                } else if (ke.getKeyCode() == KeyEvent.VK_DOWN) {
                    f.setVelY(f.getVelY() + .05);
                } else if(ke.getKeyChar() == ' ') {
                    HackerBullets pl = new HackerBullets();
                    pl.setVelX(f.getVelX()*2);
                    pl.setVelY(f.getVelY()*2);
                    pl.setX(f.getX()+f.getWidth()*.5);
                    pl.setY(f.getY()+f.getHeight()*.5);
                    pl.init(sc);
                    sc.addSprite(pl);
                }
            }
        });
        
        f.init(sc);
        sc.start(0,10);
    }
}