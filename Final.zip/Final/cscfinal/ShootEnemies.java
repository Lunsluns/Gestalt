/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cscfinal;

import basicgraphics.BasicFrame;
import basicgraphics.CollisionEventType;
import basicgraphics.Sprite;
import basicgraphics.SpriteCollisionEvent;
import basicgraphics.SpriteComponent;
import basicgraphics.images.Picture;
import basicgraphics.sounds.ReusableClip;
import java.applet.AudioClip;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.io.IOException;

/**
 *
 * @author Mikhail
 */
public class ShootEnemies extends Sprite {
     public Picture initialPic;
    /**
     * Initializes the sprite, setting its picture,
     * position, and speed. It also adds it to the
     * SpriteComponent.
     * 
     * @param sc
     * @throws IOException 
     */
    public void init(SpriteComponent sc) throws IOException {
        setPicture(makeRectangle(Color.orange,12));
        while(true){
            setX(Gestalt.RAND.nextInt(Gestalt.BOARD_SIZE.width)-Gestalt.SMALL);
            setY(Gestalt.RAND.nextInt(Gestalt.BOARD_SIZE.height)-Gestalt.SMALL);
            setVelX(1);
            setVelY(1);
            if (Math.abs(getX() - Gestalt.BOARD_SIZE.width / 2.5) < 3 * Gestalt.BIG
                    && Math.abs(getY() - Gestalt.BOARD_SIZE.height / 2) < 3 * Gestalt.BIG) {
                // Overlaps with center-ISH, try again
            } else {
                break;
            }
        
        }
        sc.addSprite(this);
        this.sc = sc;
    }
    
    public static Picture makeRectangle(Color color,int size) {
        Image im = BasicFrame.createImage(size, size);
        Graphics g = im.getGraphics();
        g.setColor(color);
        g.fillRect(0, 0, size, size);
        return new Picture(im);
    }
    
    
    SpriteComponent sc;
    /**
     * Here we update the velocity and picture
     * if they need updating.
     */
    @Override
    public void preMove() {
    }
    
    AudioClip clip = new ReusableClip("flight.wav");
    
    /**
     * This sprite only reacts to collisions with the
     * borders of the display region. When it does, it
     * wraps to the other side.
     * @param se 
     */
    @Override
    public void processEvent(SpriteCollisionEvent ce) {
        if (ce.eventType == CollisionEventType.WALL) {
                      if (ce.xlo) {
                          setVelX(Math.abs(getVelX()));
                      }
                      if (ce.xhi) {
                          setVelX(-Math.abs(getVelX()));
                      }
                      if (ce.ylo) {
                          setVelY(Math.abs(getVelY()));
                      }
                      if (ce.yhi) {
                          setVelY(-Math.abs(getVelY()));
                      }
        }
        if (ce.xlo) {
            clip.play();
            setX(sc.getSize().width-getWidth());
        }
        if (ce.xhi) {
            clip.play();
            setX(0);
        }
        if (ce.ylo) {
            clip.play();
            setY(sc.getSize().height-getHeight());
        }
        if (ce.yhi) {
            clip.play();
            setY(0);
        }
    }

}