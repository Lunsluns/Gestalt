/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cscfinal;

import basicgraphics.BasicFrame;
import basicgraphics.CollisionEventType;
import basicgraphics.Sprite;
import basicgraphics.SpriteCollisionEvent;
import basicgraphics.SpriteComponent;
import basicgraphics.images.Picture;
import basicgraphics.sounds.ReusableClip;
import java.applet.AudioClip;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.JOptionPane;

/**
 *
 * @author Mikhail
 */
public class IndestructableBullets extends Sprite {
    //probably not the best way to do this, but I want to be able to have a lives option.
    //For this, I'm setting the lives to 3.
    static int livesLost=3;
    SpriteComponent sc;
    /**
     * Creates a picture of a ball with the given color and size.
     * @param color
     * @param size
     * @return 
     */
    
    public static Picture makeIndestructibleBall(Color color,int size) {
        Image im = BasicFrame.createImage(size, size);
        Graphics g = im.getGraphics();
        g.setColor(color);
        g.fillOval(0, 0, size, size);
        return new Picture(im);
    }
    
    /**
     * Just sets the picture.
     * @param sc 
     */
    public void init(SpriteComponent sc) {
        setPicture(makeIndestructibleBall(Color.pink,20));
    }
    
    AudioClip clip = new ReusableClip("die.wav");
    
    /**
     * Disappears if it comes in contact with the display
     * boundary.
     * @param se 
     */
    @Override
    public void processEvent(SpriteCollisionEvent se) {
        
        if (se.eventType == CollisionEventType.SPRITE) {
            if (se.sprite2 instanceof Hacker) {
                clip.play();
                se.sprite2.setActive(false);
                JOptionPane.showMessageDialog(sc, "Hacking failed! You died.");
                System.exit(0);
            }
            if (se.sprite2 instanceof HackerBullets) {
                clip.play();
            }
        }
    }
}
