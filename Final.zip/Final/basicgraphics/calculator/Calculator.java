/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package basicgraphics.calculator;

import basicgraphics.BasicFrame;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.UIManager;

/**
 *
 * @author sbrandt
 */
public class Calculator {
    public final static String[][] layout = {
        {"D","D","D","C","Sin"},
        {"1","2","3","+","Cos"},
        {"4","5","6","-","Log"},
        {"7","8","9","*", "Exp"},
        {"0",".","?","/","="},
        {"M","M","R","R","="}
    };
    double value_, previousValue, memoryValue;
    String operator;
    boolean negative = false;
    double decimal=1.0;
    JLabel display = new JLabel("0",JLabel.CENTER);
    public BasicFrame bf = new BasicFrame("Calculator");
    
    // This is called an accessor
    public double getValue() {
        if(!negative){
        return value_;
        }
        else return -value_;
        
    }
    public void setValue(double v) {
        value_ = v;
    }
    
    public void init() {
        // Here "D" refers to the name in the
        // layout. Because "D" is repeated three
        // times, it is as wide as the three buttons
        // below it.
        bf.add(layout,"D",display);
        
        for(int i=0;i<=9;i++) {
            final int key = i;
            // Create the button, providing the display
            // text drawn on the button.
            JButton b = new JButton(""+i);
            b.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if(decimal == 1.0) {
                        value_ = 10*value_+key;
                    } else {
                        value_ = value_ + key*decimal;
                        decimal *= 0.1;
                    }
                    update();
                }
            });
            // Provide the name in the layout describing
            // where the button goes.
            bf.add(layout, ""+i, b);
        }
        // Iterate through button names.
        for(String s : new String[]{"+","-","/","*","="}) {
            final String op = s;
            JButton b = new JButton(op);
            b.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if("=".equals(op)) {
                        calc(operator);
                        setValue(previousValue);
                        operator = null;
                        negative = false;
                    } else {
                        previousValue = getValue();
                        setValue(0.0);
                        operator = op;
                        negative = false;
                    }
                    decimal = 1.0;
                    update();
                }
            });
            bf.add(layout,op,b);
        }
        
        // The text on the button is "Clr"
        JButton clear = new JButton("Clr");
        clear.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setValue(0.0);
                previousValue = 0;
                operator = null;
                decimal = 1.0;
                update();
            }
        });
        // The place of the button in the layout is
        // given by "C".
        bf.add(layout,"C",clear);
        
        //text on the button is "Sin"
                JButton sin = new JButton("Sin");
        sin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                operator = null;
                setValue(Math.sin(getValue()));
                update();
            }
        });
        // The place of the button in the layout is
        // given by "Sin".
        bf.add(layout,"Sin",sin);
        
        //text on the button is "Sin"
                JButton cos = new JButton("Cos");
        cos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                operator = null;
                setValue(Math.cos(getValue()));
                update();
            }
        });
        // The place of the button in the layout is
        // given by "Cos".
        bf.add(layout,"Cos",cos);
        
        //text on the button is "Sin"
                JButton exp = new JButton("Exp");
        exp.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                operator = null;
                setValue(Math.exp(getValue()));
                update();
            }
        });
        // The place of the button in the layout is
        // given by "Exp".
        bf.add(layout,"Exp",exp);
        
        //text on the button is "Log"
                JButton log = new JButton("Log");
        log.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                operator = null;
                setValue(Math.log(getValue()));
                update();
            }
        });
        // The place of the button in the layout is
        // given by "Log".
        bf.add(layout,"Log",log);
        
       //text on the button is "M+"
                JButton M = new JButton("M+");
        M.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                memoryValue = getValue();
                update();
            }
        });
        // The place of the button in the layout is
        // given by "M+".
        bf.add(layout,"M",M);  
        
        //text on the button is "M+"
                JButton R = new JButton("MR");
        R.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setValue(memoryValue);
                update();
            }
        });
        // The place of the button in the layout is
        // given by "MR".
        bf.add(layout,"R",R); 
  
        // "+/-" is the text on the button text
        JButton neg = new JButton("+/-");
        neg.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                negative = !negative;
                update();
            }
        });
        // "+/-" is the position on the display
        bf.add(layout,"?",neg);
        
        // "." is the text on the button text
        JButton dot = new JButton(".");
        dot.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                decimal *= .1;
            }
        });
        // "." is the position on the display
        bf.add(layout,".",dot);
        Font f = new Font("Courier", Font.BOLD, 30);
        bf.setAllFonts(f);
        bf.show();
    }
    public void calc(String op) {
        if ("+".equals(op)) {
            previousValue = previousValue + getValue();
        } else if ("-".equals(op)) {
            previousValue = previousValue - getValue();
        } else if ("*".equals(op)) {
            previousValue = previousValue * getValue();
        } else if ("/".equals(op)) {
            previousValue = previousValue / getValue();
        }
    }
    final static DecimalFormat df = new DecimalFormat("#.######");
    public void update() {
        if(operator == null) {
            display.setText(df.format(getValue()));
        } else {
            display.setText(df.format(previousValue)+operator+df.format(getValue()));
        }
    }
    public static void main(String[] args) {
        Calculator c = new Calculator();
        c.init();
    }
}
